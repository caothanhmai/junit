mvn clean test jacoco:report

to generate report
